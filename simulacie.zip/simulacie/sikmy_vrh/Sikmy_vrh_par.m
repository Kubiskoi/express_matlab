function [] = Sikmy_vrh_par(map_input)
    % Parametre pre model so sikmym vrhom
    % v0 - [m/s] pociatocna rychlost v smere hodu
    % alfa_deg - [deg] uhol vrhu v stupnoch

    v0 = map_input('v0');
    alfa_deg = map_input('alfa');
    userFromWeb = map_input('logged_user');
    ipadrs = map_input('ipadrs');
    port = map_input('port');
    from = map_input('from');


    % [m/s^2] gravitacne zrychlenie
    g = 9.81;
    % overujem vstupy v html aj v javascripte
    %if alfa_deg > 90; alfa_deg=90; end;
    %if alfa_deg < 0;  alfa_deg=0;  end;    
    
    % [rad] uhol vrhu v radianoch
    alfa_rad = alfa_deg*2*pi/360;   

    % [s] cas dopadu
    td = 2*v0*sin(alfa_rad)/g;
    
    % [m] dolet
    d  = v0^2*sin(2*alfa_rad)/g;
    
    % [m] maximalna vyska
    h  = v0^2*(sin(alfa_rad))^2/g/2; 
    %h  = (v0^2*(sin(alfa_rad))^2)/(g*2); 

    % copy all function variable to master scope for projectile_sim
    A = who;
    for i = 1:length(A)
        assignin('base', A{i}, eval(A{i}));
    end
end


