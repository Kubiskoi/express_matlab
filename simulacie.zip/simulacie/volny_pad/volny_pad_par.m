function [] = volny_pad_par(map_input)
    % Parametre pre model volneho padu
    % height - [m] pociatocna vyska

    height = map_input('height');
    userFromWeb = map_input('logged_user');
    ipadrs = map_input('ipadrs');
    port = map_input('port');
    from = map_input('from');


    % [m/s^2] gravitacne zrychlenie
    g = 9.81;

    % [s] cas dopadu
    td = sqrt((2*height)/g);

    % skopiruje premenne do scopeu
    A = who;
    for i = 1:length(A)
        assignin('base', A{i}, eval(A{i}));
    end
end


