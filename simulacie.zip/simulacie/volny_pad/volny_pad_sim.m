% Add required libraries
addpath('libs/jsonlab-1.2');
% Define API to communicate
api = strcat('http://',ipadrs,':',port,'/');
url = [api 'matlab/result'];

% Object with definition of transmission data
options = weboptions('MediaType', 'application/json', 'CharacterEncoding', 'UTF-8', 'ContentType', 'json', 'RequestMethod', 'post', 'ArrayFormat', 'json');

schema = 'volny_pad_schema';
load_system(schema);
set_param(schema, 'SimulationCommand', 'Start');

timeToSent = [];
timeWas = [];
vyToSent = [];
vyWas = [];
hToSent = [];
hWas = [];

while 1
	set_param(schema, 'SimulationCommand', 'WriteDataLogs');
	
	%v prvom stlpci je cas
	ScopeDataTime(:,1) = [];
	ScopeDataVY(:,1) = [];
	ScopeDataH(:,1) = [];


	timeToSent = setdiff(ScopeDataTime, timeWas, 'stable');
   	timeWas = ScopeDataTime;

   	vyToSent = setdiff(ScopeDataVY, vyWas, 'stable');
   	vyWas = ScopeDataVY;

   	hToSent = setdiff(ScopeDataH, hWas, 'stable');
   	hWas = ScopeDataH;

	n = length(timeToSent);
   	timeReady = zeros(1,n); 
   	vyReady = zeros(1,n);
   	hReady = zeros(1,n);

   	for i=1:n
       timeReady(i) = round(timeToSent(i), 2);
       vyReady(i) = round(vyToSent(i), 2);
       hReady(i) = (height - round(hToSent(i), 2));
   	end

   	% CAS SA MUSI VOLAT time !!!
   	json = savejson('result', struct('units',struct('time','s','vy','m/s','h','m'),'user', userFromWeb,'from',from, 'status', 'running', 'data', struct('time', timeReady, 'vy', vyReady,'h',hReady)));
   	response = webwrite(url, json, options);



	% If simulation ends break the while loop
	if strcmp(get_param(schema,'SimulationStatus'), 'running') == 0
		json = savejson('result', struct('user', userFromWeb,'from',from, 'status', 'stopped', 'data', []));
		response = webwrite(url,json,options);
	    break
	end
	pause(0.1);
end
